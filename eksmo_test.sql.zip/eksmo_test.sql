-- phpMyAdmin SQL Dump
-- version 4.1.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Май 08 2014 г., 12:03
-- Версия сервера: 5.5.23
-- Версия PHP: 5.5.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `eksmo_test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cinemas`
--

CREATE TABLE IF NOT EXISTS `cinemas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(500) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `cinemas`
--

INSERT INTO `cinemas` (`id`, `name`) VALUES
(1, 'Заря'),
(2, 'Победа'),
(3, 'Дружба');

-- --------------------------------------------------------

--
-- Структура таблицы `films`
--

CREATE TABLE IF NOT EXISTS `films` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(500) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `films`
--

INSERT INTO `films` (`id`, `name`) VALUES
(1, 'Бэтмэн'),
(2, 'Супермэн'),
(3, 'Шрек');

-- --------------------------------------------------------

--
-- Структура таблицы `halls`
--

CREATE TABLE IF NOT EXISTS `halls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cinema_id` int(10) unsigned NOT NULL,
  `name` varchar(500) CHARACTER SET utf8 NOT NULL,
  `seating_capacity` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `halls`
--

INSERT INTO `halls` (`id`, `cinema_id`, `name`, `seating_capacity`) VALUES
(1, 1, 'VIP зал', 30),
(2, 1, 'Зал эконом', 20),
(3, 2, 'Общий зал', 34),
(4, 3, 'Мини-зал', 10);

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` int(10) unsigned NOT NULL,
  `code` varchar(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `session_id`, `code`) VALUES
(1, 1, 'dsf32eqdwq'),
(10, 5, 'vyEYbGZD');

-- --------------------------------------------------------

--
-- Структура таблицы `orders_places`
--

CREATE TABLE IF NOT EXISTS `orders_places` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `seat_number` int(10) unsigned NOT NULL COMMENT 'номер места',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `orders_places`
--

INSERT INTO `orders_places` (`id`, `order_id`, `seat_number`) VALUES
(1, 1, 22),
(2, 1, 24),
(15, 10, 1),
(16, 10, 3),
(17, 10, 5),
(18, 10, 7);

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `film_id` int(10) unsigned NOT NULL,
  `hall_id` int(10) unsigned NOT NULL,
  `start_time` int(10) unsigned NOT NULL,
  `end_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `film_id`, `hall_id`, `start_time`, `end_time`) VALUES
(1, 1, 1, 1404289800, 1404297000),
(2, 2, 2, 1404311400, 1404318600),
(3, 1, 3, 1404289800, 1404297000),
(4, 2, 3, 1404311400, 1404318600),
(5, 3, 4, 1399626600, 1399635900);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
